//
//  CreateAccountView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI
import RealmSwift

struct customViewModifier: ViewModifier {
    var roundedCornes: CGFloat
    var startColor: Color
    var endColor: Color
    var textColor: Color

    func body(content: Content) -> some View {
        content
            .padding()
            .background(LinearGradient(gradient: Gradient(colors: [startColor, endColor]), startPoint: .topLeading, endPoint: .bottomTrailing))
            .cornerRadius(roundedCornes)
            .padding(3)
            .foregroundColor(textColor)
            .overlay(RoundedRectangle(cornerRadius: roundedCornes)
                        .stroke(LinearGradient(gradient: Gradient(colors: [startColor, endColor]), startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 2.5))
            .font(.custom("Open Sans", size: 18))

            .shadow(radius: 10)
    }
}



struct LoginView: View {
    @State var email = ""
    @State var password = ""
    @State private var userIsLoggedIn = false
    @State private var showAlert = false
    
    @AppStorage ("isUserLoggedIn") var isUserLoggedIn: Bool = false
    
    var body: some View {
        if userIsLoggedIn {
            ContentView(userisLoggedIn: $userIsLoggedIn)
        } else {
            content
        }
    }
    
    var content: some View {
        NavigationStack {
            VStack {
                
                Text("Login")
                    .bold()
                    .font(.title)
                
                TextField("Email", text: $email)
                    
                    .modifier(customViewModifier(roundedCornes: 9, startColor: .red, endColor: .blue, textColor: .white))
                SecureField("Password", text: $password)
                    
                    .modifier(customViewModifier(roundedCornes: 9, startColor: .red, endColor: .blue, textColor: .white))
                
                Button {
                    RealmAuth(email: email, password: password)
                } label: {
                    Text("Log In")
                }.buttonStyle(.bordered)
                
                NavigationLink {
                    CreateAccountView()
                } label: {
                    Text("Create Account?")
                }.buttonStyle(.bordered)
            }
        }
        .onAppear {
            if isUserLoggedIn == true {
                userIsLoggedIn = true
            }
        }
    }
    
    func RealmAuth(email: String, password: String){
        let app = App(id: "doctagon-aymnk")
        
        app.login(credentials: Credentials.emailPassword(email: email, password: password)) { (result) in
            switch result {
            case .failure(let error):
                print("Login failed: \(error.localizedDescription)")
            case .success(let user):
                print("Successfully logged in as user \(user)")

                userIsLoggedIn = true
                isUserLoggedIn = true
            }
        }
    }
}

struct CreateAccountView_Previews: PreviewProvider {
    static var previews: some View {
        CreateAccountView()
    }
}
