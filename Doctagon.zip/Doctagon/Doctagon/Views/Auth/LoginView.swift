//
//  LoginView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI
import RealmSwift


struct CreateAccountView: View {
    
    @State var email = ""
    @State var password = ""
    @State private var userIsLoggedIn = false
    @State private var showAlert = false
    
    @AppStorage ("isUserLoggedIn") var isUserLoggedIn: Bool = false
    
    var body: some View {
        
        if userIsLoggedIn {
            ContentView(userisLoggedIn: $userIsLoggedIn).navigationBarBackButtonHidden(true)
        } else {
            content
        }
    }
    
    var content: some View {
        VStack {
            Text("Create Account")
                .bold()
                .font(.title)
            Spacer()
            
            TextField("Email", text: $email)
                .modifier(customViewModifier(roundedCornes: 9, startColor: .red, endColor: .blue, textColor: .white))
                
            SecureField("Password", text: $password)
                .modifier(customViewModifier(roundedCornes: 9, startColor: .red, endColor: .blue, textColor: .white))
                
            
            Button {
                RealmRegister(email: email, password: password)
            } label: {
                Text("Register")
            }.buttonStyle(.bordered)
            Spacer()
            
        }
        .padding()
        .onAppear {
            if isUserLoggedIn == true {
                userIsLoggedIn = true
            }
        }
    }
    
    func RealmRegister(email: String, password: String){
        let app = App(id: "doctagon-aymnk")
        
        let client = app.emailPasswordAuth
        client.registerUser(email: email, password: password) { (error) in
            guard error == nil else {
                print("Failed to register: \(error!.localizedDescription)")
                return
            }
            print("Successfully registered user.")
            
            RealmAuth(email: email, password: password)
        }
    }
    
    func RealmAuth(email: String, password: String){
        let app = App(id: "doctagon-aymnk")
        
        app.login(credentials: Credentials.emailPassword(email: email, password: password)) { (result) in
            switch result {
            case .failure(let error):
                print("Login failed: \(error.localizedDescription)")
            case .success(let user):
                print("Successfully logged in as user \(user)")

                userIsLoggedIn = true
                isUserLoggedIn = true
            }
        }
    }
    
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
