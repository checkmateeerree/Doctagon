//
//  HomeView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationStack {
            
            ZStack {
                VStack {
                    Text("Welcome")
                        .bold()
                }
                
                NavigationLink {
                    QuestionView(bodyPart: "nil")
                } label: {
                    Image(systemName: "plus.circle")
                        .resizable()
                        .frame(width: 50, height: 50)
                }
                .padding(.top, 550)
                .padding(.leading, 250)
                
            }
            .navigationTitle("Home")
        }
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
