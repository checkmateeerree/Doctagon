//
//  DiseaseView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/20/22.
//

import SwiftUI

struct DiseaseView: View {
    
    @State var diseases:[Diseases]
    
    var body: some View {
        VStack {
            Text(diseases.description)
        }
    }
}
