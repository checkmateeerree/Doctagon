//
//  CheckUpView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI

struct CheckUpView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    Text("Click the Body Part That Hurts")
                        .bold()
                        .font(.title2)
                    VStack {
                        
                        NavigationLink {
                            QuestionView(bodyPart: "head")
                        } label: {
                            Circle()
                                .frame(width: 100)
                        }
                        
                        HStack {
                            NavigationLink {
                                QuestionView(bodyPart: "left arm")
                            } label: {
                                Rectangle()
                                    .frame(width: 50, height: 200)
                                    .cornerRadius(20)
                                    .padding(.bottom, 100)
                                    .padding(.top, 25)
                            }
                            
                            NavigationLink {
                                QuestionView(bodyPart: "chest")
                            } label: {
                                Rectangle()
                                    .frame(width: 125, height: 300)
                                    .cornerRadius(20)
                            }
                            
                            NavigationLink {
                                QuestionView(bodyPart: "right arm")
                            } label: {
                                Rectangle()
                                    .frame(width: 50, height: 200)
                                    .cornerRadius(20)
                                    .padding(.bottom, 100)
                                    .padding(.top, 25)
                            }
                            
                            
                        }
                        HStack {
                            
                            NavigationLink {
                                QuestionView(bodyPart: "left leg")
                            } label: {
                                Rectangle()
                                    .frame(width: 50, height: 200)
                                    .cornerRadius(20)
                            }
                            
                            NavigationLink {
                                QuestionView(bodyPart: "right leg")
                            } label: {
                                Rectangle()
                                    .frame(width: 50, height: 200)
                                    .cornerRadius(20)
                            }
                            
                        }
                        
                        NavigationLink {
                            QuestionView(bodyPart: "full body")
                        } label: {
                            Text("Whole Body")
                                .bold()
                        }
                        .buttonStyle(.bordered)
                        .padding()
                    }
                }
            }
        }
    }
}

struct CheckUpView_Previews: PreviewProvider {
    static var previews: some View {
        CheckUpView()
    }
}
