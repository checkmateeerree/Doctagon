//
//  SettingsView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI
import RealmSwift
struct SettingsView: View {
    
    @AppStorage ("isUserLoggedIn") var isUserLoggedIn: Bool = false
    @State var userIsLoggedIn: Bool = false
    var body: some View {
        NavigationStack {
            ScrollView {
                Text("Settings")
            }
        }
    }

}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
