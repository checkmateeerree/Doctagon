//
//  DoctagonApp.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI

@main
struct DoctagonApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
