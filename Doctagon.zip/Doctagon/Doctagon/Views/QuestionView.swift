//
//  QuestionView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI

struct Diseases: Hashable, Codable {
    
}

struct QuestionView: View {
    
    var bodyPart: String
    
    @State private var searchText = ""
    
    @State var diseases:[Diseases] = []
    
    @State var bodyPain = ["Ulcers On Tongue",
                           "Vomiting",
                           "Patches In Throat",
                           "Cough",
                           "Sunken Eyes",
                           "Indigestion",
                           "Headache",
                           "Nausea",
                           "Pain Behind The Eyes",
                           "Back Pain",
                           "Constipation",
                           "Abdominal Pain","Yellowing Of Eyes",
                           "Acute Liver Failure",
                           "Swelling Of Stomach",
                           "Swelled Lymph Nodes",
                           "Malaise",
                           "Blurred And Distorted Vision",
                           "Phlegm",
                           "Throat Irritation",
                           "Redness Of Eyes",
                           "Sinus Pressure",
                           "Runny Nose",
                           "Congestion",
                           "Chest Pain",
                           "Fast Heart Rate",
                           "Pain During Bowel Movements",
                           "Pain In Anal Region",
                           "Bloody Stool",
                           "Irritation In Anus"]
    @State var head = ["Ulcers On Tongue",
                       "Vomiting",
                       "Patches In Throat",
                       "Cough",
                       "Sunken Eyes",
                       "Indigestion",
                       "Headache",
                       "Nausea",
                       "Pain Behind The Eyes",
                       "Back Pain",
                       "Constipation",
                       "Abdominal Pain","Yellowing Of Eyes",
                       "Acute Liver Failure",
                       "Swelling Of Stomach",
                       "Swelled Lymph Nodes",
                       "Malaise",
                       "Blurred And Distorted Vision",
                       "Phlegm",
                       "Throat Irritation",
                       "Redness Of Eyes",
                       "Sinus Pressure",
                       "Runny Nose",
                       "Congestion",
                       "Chest Pain",
                       "Fast Heart Rate",
                       "Pain During Bowel Movements",
                       "Pain In Anal Region",
                       "Bloody Stool",
                       "Irritation In Anus",
                       "Dizziness",
                       "Cramps",
                       "Bruising",
                       "Obesity",
                       "Swollen Legs",
                       "Swollen Blood Vessels",
                       "Puffy Face And Eyes",
                       "Enlarged Thyroid",
                       "Brittle Nails",
                       "Swollen Extremeties",
                       "Excessive Hunger",
                       "Extra Marital Contacts",
                       "Drying And Tingling Lips",
                       "Slurred Speech",
                       "Knee Pain",
                       "Hip Joint Pain",
                       "Muscle Weakness",
                       "Stiff Neck",
                       "Swelling Joints",
                       "Movement Stiffness",
                       "Spinning Movements",
                       "Loss Of Balance",
                       "Unsteadiness",
                       "Weakness Of One Body Side",
                       "Loss Of Smell",
                       "Bladder Discomfort",
                       "Foul Smell Of urine",
                       "Continuous Feel Of Urine",
                       "Passage Of Gases",
                       "Internal Itching",
                       "Toxic Look (typhos)",
                       "Depression",
                       "Irritability"]
    @State var neckPain = ["Dizziness",
                           "Cramps",
                           "Bruising",
                           "Obesity",
                           "Swollen Legs",
                           "Swollen Blood Vessels",
                           "Puffy Face And Eyes",
                           "Enlarged Thyroid",
                           "Brittle Nails",
                           "Swollen Extremeties",
                           "Excessive Hunger",
                           "Extra Marital Contacts",
                           "Drying And Tingling Lips",
                           "Slurred Speech",
                           "Knee Pain",
                           "Hip Joint Pain",
                           "Muscle Weakness",
                           "Stiff Neck",
                           "Swelling Joints",
                           "Movement Stiffness",
                           "Spinning Movements",
                           "Loss Of Balance",
                           "Unsteadiness",
                           "Weakness Of One Body Side",
                           "Loss Of Smell",
                           "Bladder Discomfort",
                           "Foul Smell Of urine",
                           "Continuous Feel Of Urine",
                           "Passage Of Gases",
                           "Internal Itching",
                           "Toxic Look (typhos)",
                           "Depression",
                           "Irritability"]
    @State var musclePain = ["Altered Sensorium",
                             "Red Spots Over Body"]
    @State var legPain = ["Altered Sensorium",
                          "Red Spots Over Body",
                          "Ulcers On Tongue",
                          "Vomiting",
                          "Patches In Throat",
                          "Cough",
                          "Sunken Eyes",
                          "Indigestion",
                          "Headache",
                          "Nausea",
                          "Pain Behind The Eyes",
                          "Back Pain",
                          "Constipation",
                          "Abdominal Pain","Yellowing Of Eyes",
                          "Acute Liver Failure",
                          "Swelling Of Stomach",
                          "Swelled Lymph Nodes",
                          "Malaise",
                          "Blurred And Distorted Vision",
                          "Phlegm",
                          "Throat Irritation",
                          "Redness Of Eyes",
                          "Sinus Pressure",
                          "Runny Nose",
                          "Congestion",
                          "Chest Pain",
                          "Fast Heart Rate",
                          "Pain During Bowel Movements",
                          "Pain In Anal Region",
                          "Bloody Stool",
                          "Irritation In Anus"]
    @State var names = ["Altered Sensorium",
                        "Red Spots Over Body",
                        "Ulcers On Tongue",
                        "Vomiting",
                        "Patches In Throat",
                        "Cough",
                        "Sunken Eyes",
                        "Indigestion",
                        "Headache",
                        "Nausea",
                        "Pain Behind The Eyes",
                        "Back Pain",
                        "Constipation",
                        "Abdominal Pain","Yellowing Of Eyes",
                        "Acute Liver Failure",
                        "Swelling Of Stomach",
                        "Swelled Lymph Nodes",
                        "Malaise",
                        "Blurred And Distorted Vision",
                        "Phlegm",
                        "Throat Irritation",
                        "Redness Of Eyes",
                        "Sinus Pressure",
                        "Runny Nose",
                        "Congestion",
                        "Chest Pain",
                        "Fast Heart Rate",
                        "Pain During Bowel Movements",
                        "Pain In Anal Region",
                        "Bloody Stool",
                        "Irritation In Anus",
                        "Abnormal Menstruation",
                        "Dischromic  Patches",
                        "Watering From Eyes",
                        "Increased Appetite",
                        "Polyuria",
                        "Family History",
                        "Mucoid Sputum",
                        "Rusty Sputum",
                        "Lack Of Concentration",
                        "Visual Disturbances",
                        "Receiving Blood Transfusion",
                        "Receiving Unsterile Injections",
                        "Coma",
                        "Stomach Bleeding",
                        "Distention Of Abdomen",
                        "History Of Alcohol Consumption",
                        "Fluid Overload.1",
                        "Blood In Sputum",
                        "Prominent Veins On Calf",
                        "Palpitations",
                        "Painful Walking",
                        "Pus Filled Pimples",
                        "Blackheads",
                        "Scurring",
                        "Skin Peeling",
                        "Silver Like Dusting",
                        "Small Dents In Nails",
                        "Inflammatory Nails",
                        "Blister",
                        "Red Sore Around Nose",
                        "Yellow Crust Ooze",
                        "Dizziness",
                        "Cramps",
                        "Bruising",
                        "Obesity",
                        "Swollen Legs",
                        "Swollen Blood Vessels",
                        "Puffy Face And Eyes",
                        "Enlarged Thyroid",
                        "Brittle Nails",
                        "Swollen Extremeties",
                        "Excessive Hunger",
                        "Extra Marital Contacts",
                        "Drying And Tingling Lips",
                        "Slurred Speech",
                        "Knee Pain",
                        "Hip Joint Pain",
                        "Muscle Weakness",
                        "Stiff Neck",
                        "Swelling Joints",
                        "Movement Stiffness",
                        "Spinning Movements",
                        "Loss Of Balance",
                        "Unsteadiness",
                        "Weakness Of One Body Side",
                        "Loss Of Smell",
                        "Bladder Discomfort",
                        "Foul Smell Of urine",
                        "Continuous Feel Of Urine",
                        "Passage Of Gases",
                        "Internal Itching",
                        "Toxic Look (typhos)",
                        "Depression",
                        "Irritability"]
    @State var bellyPain = ["Abnormal Menstruation",
                            "Dischromic  Patches",
                            "Watering From Eyes",
                            "Increased Appetite",
                            "Polyuria",
                            "Family History",
                            "Mucoid Sputum",
                            "Rusty Sputum",
                            "Lack Of Concentration",
                            "Visual Disturbances",
                            "Receiving Blood Transfusion",
                            "Receiving Unsterile Injections",
                            "Coma",
                            "Stomach Bleeding",
                            "Distention Of Abdomen",
                            "History Of Alcohol Consumption",
                            "Fluid Overload.1",
                            "Blood In Sputum",
                            "Prominent Veins On Calf",
                            "Palpitations",
                            "Painful Walking",
                            "Pus Filled Pimples",
                            "Blackheads",
                            "Scurring",
                            "Skin Peeling",
                            "Silver Like Dusting",
                            "Small Dents In Nails",
                            "Inflammatory Nails",
                            "Blister",
                            "Red Sore Around Nose",
                            "Yellow Crust Ooze"]
    @State var armPain = [ "Dizziness",
                           "Cramps",
                           "Bruising",
                           "Obesity",
                           "Swollen Legs",
                           "Swollen Blood Vessels",
                           "Puffy Face And Eyes",
                           "Enlarged Thyroid",
                           "Brittle Nails",
                           "Swollen Extremeties",
                           "Excessive Hunger",
                           "Extra Marital Contacts",
                           "Drying And Tingling Lips",
                           "Slurred Speech",
                           "Knee Pain",
                           "Hip Joint Pain",
                           "Muscle Weakness",
                           "Stiff Neck",
                           "Swelling Joints",
                           "Movement Stiffness",
                           "Spinning Movements",
                           "Loss Of Balance",
                           "Unsteadiness",
                           "Weakness Of One Body Side",
                           "Loss Of Smell",
                           "Bladder Discomfort",
                           "Foul Smell Of urine",
                           "Continuous Feel Of Urine",
                           "Passage Of Gases",
                           "Internal Itching",
                           "Toxic Look (typhos)",
                           "Depression",
                           "Irritability",
                           "Altered Sensorium",
                           "Red Spots Over Body"]
    
    @State var symptoms = []
    
    var body: some View {
        NavigationStack {
            VStack {
                List {
                    ForEach(searchResults, id: \.self) { name in
                        Button {
                            symptoms.append(name)
                            print(symptoms)
                        } label: {
                            Text(name)
                        }
                    }
                }
                .searchable(text: $searchText)
                .navigationTitle("Symptoms")
                
                HStack {
                    Button {
                        makePOSTRequest(symptoms: symptoms)
                    } label: {
                        Text("Submit")
                    }.buttonStyle(BorderedButtonStyle())
                    
                    
                }
            }
        }
    }
    
    var searchResults: [String] {
        if searchText.isEmpty {
            return names
        } else {
            return names.filter { $0.contains(searchText) }
        }
    }
    
    func makePOSTRequest(symptoms: Array<Any>) {
        
        print("entered request function")
        
        guard let url = URL(string: "https://doctagon.herokuapp.com/diagnose") else {
            print("error with getting the URL")
            return
        }
        print("got the URL")
        
        var request = URLRequest(url: url)
        print("Got the request")
        // method, body, headers?
        request.httpMethod = "POST"
        print("got the http.method = 'POST'")
        
        // might not need this --> request.setValue(" symptoms", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "symptoms": symptoms
        ]
        print("got the body")
        
        print("About to enter the .httpBody part of the code")
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: .fragmentsAllowed)
        //Make the request
        let task = URLSession.shared.dataTask(with: request) { data, _, error in
            guard let data = data, error == nil else {
                print("error with making sure that there is data")
                return
            }
            print("got data")
            
            do {
                let response = try JSONSerialization.jsonObject(with: data)
                print("SUCCESS \(response)")
                
                //let newDiseasese = try JSONDecoder().decode(diseases, from: response as! Data)
                
                //DispatchQueue.main.async {
                //    self.diseases = response as! [String: AnyHashable])
                //}
                
                print(self.diseases)
               
                
                
            } catch {
                print("error with the conversion of the JSOn")
                print(error)
            }
            
        }
        
        task.resume()
    }
    
}

struct QuestionView_Previews: PreviewProvider {
    static var previews: some View {
        QuestionView(bodyPart: "head")
    }
}
