//
//  ContentView.swift
//  Doctagon
//
//  Created by Anish Rangdal on 11/19/22.
//

import SwiftUI

struct ContentView: View {
    @State var selectedTab = 0
    @Binding var userisLoggedIn: Bool
    
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView()
                .tabItem {
                    VStack {
                        Image(systemName: "house.circle")
                        Text("Home")
                    }
                }
            SettingsView()
                .tabItem {
                    VStack {
                        Image(systemName: "gear.circle")
                        Text("Settings")
                    }
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(userisLoggedIn: .constant(true))
    }
}
